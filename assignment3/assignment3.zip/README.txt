Run from command line:

python make.py
